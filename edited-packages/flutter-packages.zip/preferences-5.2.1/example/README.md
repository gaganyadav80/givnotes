# preferences_example

An example project for the preferences package
