library flutter_app_lock;

export 'src/widgets/app_lock.dart';
